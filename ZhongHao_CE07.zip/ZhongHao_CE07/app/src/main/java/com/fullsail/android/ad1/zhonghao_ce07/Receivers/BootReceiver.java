// Hao Zhong
// AD1 - 202111
// BootReceiver.java
package com.fullsail.android.ad1.zhonghao_ce07.Receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

    }
}
